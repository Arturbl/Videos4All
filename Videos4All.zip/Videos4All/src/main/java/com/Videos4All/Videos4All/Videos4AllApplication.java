package com.Videos4All.Videos4All;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Videos4AllApplication {
	public static void main(String[] args) {
		SpringApplication.run(Videos4AllApplication.class, args);
	}
}